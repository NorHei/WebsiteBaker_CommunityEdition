<?php
$plugin_directory   = '683356a74c7bd64a0';
$plugin_name        = 'Relative URL';
$plugin_version     = '';
$plugin_status      = '';
$plugin_platform    = '';
$plugin_author      = '';
$plugin_license     = '';
$plugin_description = '';