<?php
if(!defined('WB_PATH')) die(header('Location: index.php'));  
opf_register_filter('a:39:{i:0;s:1:"4";i:1;s:1:"1";s:8:"userfunc";s:1:"1";i:2;s:1:"5";i:3;s:1:"1";s:6:"active";s:1:"1";i:4;s:1:"1";s:9:"allowedit";s:1:"1";i:5;s:1:"1";s:15:"allowedittarget";s:1:"1";i:6;s:12:"Relative URL";s:4:"name";s:12:"Relative URL";i:7;s:1007:"<?php
function opff_rel_url(&$content, $page_id, $section_id, $module, $wb) {
    $sAppUrl  = rtrim(str_replace(\'\\\\\', \'/\', WB_URL), \'/\').\'/\';
    $sAppPath = rtrim(str_replace(\'\\\\\', \'/\', WB_PATH), \'/\').\'/\';
    $content = preg_replace_callback(
        \'/((?:href|src)\\s*=\\s*")([^\\?\\"]*?)/isU\',
        function ($aMatches) use ($sAppUrl, $sAppPath) {
            $sAppRel = preg_replace(\'/^https?:\\/\\/[^\\/]*(.*)$/is\', \'$1\', $sAppUrl);
            $aMatches[2] = str_replace(\'\\\\\', \'/\', $aMatches[2]);
            $aMatches[2] = preg_replace(\'/^\'.preg_quote($sAppUrl, \'/\').\'/is\', \'\', $aMatches[2]);
            $aMatches[2] = preg_replace(\'/(\\.+\\/)|(\\/+)/\', \'/\', $aMatches[2]);
            if (!is_readable($sAppPath.$aMatches[2])) {
            // in case of death link show original link
                return $aMatches[0];
            } else {
                return $aMatches[1].$sAppRel.$aMatches[2];
            }
        },
        $content
    );
  
  
    return(TRUE);
}
?>";s:4:"func";s:1007:"<?php
function opff_rel_url(&$content, $page_id, $section_id, $module, $wb) {
    $sAppUrl  = rtrim(str_replace(\'\\\\\', \'/\', WB_URL), \'/\').\'/\';
    $sAppPath = rtrim(str_replace(\'\\\\\', \'/\', WB_PATH), \'/\').\'/\';
    $content = preg_replace_callback(
        \'/((?:href|src)\\s*=\\s*")([^\\?\\"]*?)/isU\',
        function ($aMatches) use ($sAppUrl, $sAppPath) {
            $sAppRel = preg_replace(\'/^https?:\\/\\/[^\\/]*(.*)$/is\', \'$1\', $sAppUrl);
            $aMatches[2] = str_replace(\'\\\\\', \'/\', $aMatches[2]);
            $aMatches[2] = preg_replace(\'/^\'.preg_quote($sAppUrl, \'/\').\'/is\', \'\', $aMatches[2]);
            $aMatches[2] = preg_replace(\'/(\\.+\\/)|(\\/+)/\', \'/\', $aMatches[2]);
            if (!is_readable($sAppPath.$aMatches[2])) {
            // in case of death link show original link
                return $aMatches[0];
            } else {
                return $aMatches[1].$sAppRel.$aMatches[2];
            }
        },
        $content
    );
  
  
    return(TRUE);
}
?>";i:8;s:10:"8page_last";s:4:"type";s:10:"8page_last";i:9;s:0:"";s:4:"file";s:0:"";i:10;s:0:"";s:7:"csspath";s:0:"";i:11;s:12:"opff_rel_url";s:8:"funcname";s:12:"opff_rel_url";i:12;s:0:"";s:9:"configurl";s:0:"";i:13;s:0:"";s:6:"plugin";s:17:"683356a74c7bd64a0";i:14;s:6:"a:0:{}";s:8:"helppath";s:6:"a:0:{}";i:15;s:6:"a:0:{}";s:7:"modules";a:0:{}i:16;s:103:"a:1:{s:2:"EN";s:80:"Convert full qualified, local URLs into relative URLs
Original Filter from WBCE";}";s:4:"desc";a:1:{s:2:"EN";s:80:"Convert full qualified, local URLs into relative URLs
Original Filter from WBCE";}i:17;s:6:"a:0:{}";i:18;s:68:"a:5:{i:0;s:3:"all";i:1;s:1:"1";i:2;s:1:"2";i:3;s:1:"9";i:4;s:1:"0";}";i:19;s:14:"s:7:"s:0:"";";";i:20;s:7:"s:0:"";";s:17:"additional_fields";s:0:"";i:21;s:7:"s:0:"";";s:27:"additional_fields_languages";s:0:"";}', TRUE);