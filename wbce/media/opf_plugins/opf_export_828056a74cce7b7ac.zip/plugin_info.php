<?php
$plugin_directory   = '828056a74cce7b7ac';
$plugin_name        = 'Short URL';
$plugin_version     = '';
$plugin_status      = '';
$plugin_platform    = '';
$plugin_author      = '';
$plugin_license     = '';
$plugin_description = '';