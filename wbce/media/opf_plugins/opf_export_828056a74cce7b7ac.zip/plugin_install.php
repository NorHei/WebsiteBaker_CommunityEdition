<?php
if(!defined('WB_PATH')) die(header('Location: index.php'));  
opf_register_filter('a:39:{i:0;s:1:"7";i:1;s:1:"1";s:8:"userfunc";s:1:"1";i:2;s:1:"6";i:3;s:1:"1";s:6:"active";s:1:"1";i:4;s:1:"1";s:9:"allowedit";s:1:"1";i:5;s:1:"1";s:15:"allowedittarget";s:1:"1";i:6;s:9:"Short URL";s:4:"name";s:9:"Short URL";i:7;s:594:"<?php
function opff_short_url(&$content, $page_id, $section_id, $module, $wb) {

    $sUrlStart = WB_URL.PAGES_DIRECTORY;
    $sUrlEnd = PAGE_EXTENSION;
    $sNewUrlStart = WB_URL;
    $sNewUrlEnd = \'/\';

    // This is ugly , should be replaced by a preg_replace_callback 
    preg_match_all(\'~\'.$sUrlStart.\'(.*?)\\\\\'.$sUrlEnd.\'~\', $content, $aLinks);
    foreach ($aLinks[1] as $sLink) {
        $content = str_replace(
            $sUrlStart.$sLink.$sUrlEnd, 
            $sNewUrlStart.$sLink.$sNewUrlEnd, 
            $content
        );
    }
  
  
  return(TRUE);
}
?>";s:4:"func";s:594:"<?php
function opff_short_url(&$content, $page_id, $section_id, $module, $wb) {

    $sUrlStart = WB_URL.PAGES_DIRECTORY;
    $sUrlEnd = PAGE_EXTENSION;
    $sNewUrlStart = WB_URL;
    $sNewUrlEnd = \'/\';

    // This is ugly , should be replaced by a preg_replace_callback 
    preg_match_all(\'~\'.$sUrlStart.\'(.*?)\\\\\'.$sUrlEnd.\'~\', $content, $aLinks);
    foreach ($aLinks[1] as $sLink) {
        $content = str_replace(
            $sUrlStart.$sLink.$sUrlEnd, 
            $sNewUrlStart.$sLink.$sNewUrlEnd, 
            $content
        );
    }
  
  
  return(TRUE);
}
?>";i:8;s:10:"8page_last";s:4:"type";s:10:"8page_last";i:9;s:0:"";s:4:"file";s:0:"";i:10;s:0:"";s:7:"csspath";s:0:"";i:11;s:14:"opff_short_url";s:8:"funcname";s:14:"opff_short_url";i:12;s:0:"";s:9:"configurl";s:0:"";i:13;s:0:"";s:6:"plugin";s:17:"828056a74cce7b7ac";i:14;s:6:"a:0:{}";s:8:"helppath";s:6:"a:0:{}";i:15;s:6:"a:0:{}";s:7:"modules";a:0:{}i:16;s:76:"a:1:{s:2:"EN";s:53:"Filter for short url modification by ruud (dev4me.nl)";}";s:4:"desc";a:1:{s:2:"EN";s:53:"Filter for short url modification by ruud (dev4me.nl)";}i:17;s:6:"a:0:{}";i:18;s:68:"a:5:{i:0;s:3:"all";i:1;s:1:"1";i:2;s:1:"2";i:3;s:1:"9";i:4;s:1:"0";}";i:19;s:14:"s:7:"s:0:"";";";i:20;s:7:"s:0:"";";s:17:"additional_fields";s:0:"";i:21;s:7:"s:0:"";";s:27:"additional_fields_languages";s:0:"";}', TRUE);