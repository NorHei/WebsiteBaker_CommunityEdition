<?php
$plugin_directory   = '641456a74c1fc89e7';
$plugin_name        = 'Css to Head';
$plugin_version     = '';
$plugin_status      = '';
$plugin_platform    = '';
$plugin_author      = '';
$plugin_license     = '';
$plugin_description = '';