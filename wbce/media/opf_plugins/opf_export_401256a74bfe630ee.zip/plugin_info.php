<?php
$plugin_directory   = '401256a74bfe630ee';
$plugin_name        = 'Class Insert';
$plugin_version     = '';
$plugin_status      = '';
$plugin_platform    = '';
$plugin_author      = '';
$plugin_license     = '';
$plugin_description = '';