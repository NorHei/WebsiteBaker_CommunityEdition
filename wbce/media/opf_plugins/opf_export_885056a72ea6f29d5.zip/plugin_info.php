<?php
$plugin_directory   = '885056a72ea6f29d5';
$plugin_name        = 'Html Compactor';
$plugin_version     = '';
$plugin_status      = '';
$plugin_platform    = '';
$plugin_author      = '';
$plugin_license     = '';
$plugin_description = '';