<?php
$plugin_directory   = '125756a74b97b70c0';
$plugin_name        = 'Droplet Filter';
$plugin_version     = '';
$plugin_status      = '';
$plugin_platform    = '';
$plugin_author      = '';
$plugin_license     = '';
$plugin_description = '';