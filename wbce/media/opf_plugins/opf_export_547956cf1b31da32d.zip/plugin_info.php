<?php
$plugin_directory   = '547956cf1b31da32d';
$plugin_name        = 'test';
$plugin_version     = '';
$plugin_status      = '';
$plugin_platform    = '';
$plugin_author      = '';
$plugin_license     = '';
$plugin_description = '';