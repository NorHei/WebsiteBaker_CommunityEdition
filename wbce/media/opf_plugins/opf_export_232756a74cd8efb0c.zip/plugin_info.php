<?php
$plugin_directory   = '232756a74cd8efb0c';
$plugin_name        = 'Html Compactor';
$plugin_version     = '';
$plugin_status      = '';
$plugin_platform    = '';
$plugin_author      = '';
$plugin_license     = '';
$plugin_description = '';