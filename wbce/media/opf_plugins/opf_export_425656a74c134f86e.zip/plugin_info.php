<?php
$plugin_directory   = '425656a74c134f86e';
$plugin_name        = 'Css to Head';
$plugin_version     = '';
$plugin_status      = '';
$plugin_platform    = '';
$plugin_author      = '';
$plugin_license     = '';
$plugin_description = '';