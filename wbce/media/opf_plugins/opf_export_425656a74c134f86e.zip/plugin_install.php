<?php
if(!defined('WB_PATH')) die(header('Location: index.php'));  
opf_register_filter('a:39:{i:0;s:1:"3";i:1;s:1:"1";s:8:"userfunc";s:1:"1";i:2;s:1:"3";i:3;s:1:"1";s:6:"active";s:1:"1";i:4;s:1:"1";s:9:"allowedit";s:1:"1";i:5;s:1:"1";s:15:"allowedittarget";s:1:"1";i:6;s:11:"Css to Head";s:4:"name";s:11:"Css to Head";i:7;s:1136:"<?php
function opff_css_to_head(&$content, $page_id, $section_id, $module, $wb) {

    $sContent=$content;
    
    $sPattern1 = \'/(?:<body.*?)(<link[^>]*?\\"text\\/css\\".*?\\/?>)/si\';
    $sPattern3 = \'/(?:<body.*?)(<link[^>]*?\\"stylesheet\\".*?\\/?>)/si\';
    $sPattern2 = \'/(?:<body.*?)(<style.*?<\\/style>)/si\';    
    
    $aInsert = array();
    while(preg_match($sPattern1, $sContent, $aMatches)) {
        $aInsert[] = $aMatches[1];
        $sContent = str_replace($aMatches[1], \'\', $sContent); 
    }
    while(preg_match($sPattern3, $sContent, $aMatches)) {
        $aInsert[] = $aMatches[1];
        $sContent = str_replace($aMatches[1], \'\', $sContent); 
    }
    while(preg_match($sPattern2, $sContent, $aMatches)) {
        $aInsert[] = $aMatches[1];
        $sContent = str_replace($aMatches[1], \'\', $sContent);
    }
    $aInsert = array_unique($aInsert);
    if(sizeof($aInsert) > 0) {
        $sInsert = "\\n".implode("\\n", $aInsert)."\\n</head>\\n<body";
        $sContent = preg_replace(\'/<\\/head>.*?<body/si\', $sInsert, $sContent, 1);
    }

    $content=$sContent;
  
    return(TRUE);
}
?>";s:4:"func";s:1136:"<?php
function opff_css_to_head(&$content, $page_id, $section_id, $module, $wb) {

    $sContent=$content;
    
    $sPattern1 = \'/(?:<body.*?)(<link[^>]*?\\"text\\/css\\".*?\\/?>)/si\';
    $sPattern3 = \'/(?:<body.*?)(<link[^>]*?\\"stylesheet\\".*?\\/?>)/si\';
    $sPattern2 = \'/(?:<body.*?)(<style.*?<\\/style>)/si\';    
    
    $aInsert = array();
    while(preg_match($sPattern1, $sContent, $aMatches)) {
        $aInsert[] = $aMatches[1];
        $sContent = str_replace($aMatches[1], \'\', $sContent); 
    }
    while(preg_match($sPattern3, $sContent, $aMatches)) {
        $aInsert[] = $aMatches[1];
        $sContent = str_replace($aMatches[1], \'\', $sContent); 
    }
    while(preg_match($sPattern2, $sContent, $aMatches)) {
        $aInsert[] = $aMatches[1];
        $sContent = str_replace($aMatches[1], \'\', $sContent);
    }
    $aInsert = array_unique($aInsert);
    if(sizeof($aInsert) > 0) {
        $sInsert = "\\n".implode("\\n", $aInsert)."\\n</head>\\n<body";
        $sContent = preg_replace(\'/<\\/head>.*?<body/si\', $sInsert, $sContent, 1);
    }

    $content=$sContent;
  
    return(TRUE);
}
?>";i:8;s:10:"8page_last";s:4:"type";s:10:"8page_last";i:9;s:0:"";s:4:"file";s:0:"";i:10;s:0:"";s:7:"csspath";s:0:"";i:11;s:16:"opff_css_to_head";s:8:"funcname";s:16:"opff_css_to_head";i:12;s:0:"";s:9:"configurl";s:0:"";i:13;s:0:"";s:6:"plugin";s:17:"425656a74c134f86e";i:14;s:6:"a:0:{}";s:8:"helppath";s:6:"a:0:{}";i:15;s:6:"a:0:{}";s:7:"modules";a:0:{}i:16;s:106:"a:1:{s:2:"EN";s:83:"Moves all css definitions from <body> into <head> section 
Basic filter from WBCE.";}";s:4:"desc";a:1:{s:2:"EN";s:83:"Moves all css definitions from <body> into <head> section 
Basic filter from WBCE.";}i:17;s:6:"a:0:{}";i:18;s:68:"a:5:{i:0;s:3:"all";i:1;s:1:"1";i:2;s:1:"2";i:3;s:1:"9";i:4;s:1:"0";}";i:19;s:14:"s:7:"s:0:"";";";i:20;s:7:"s:0:"";";s:17:"additional_fields";s:0:"";i:21;s:7:"s:0:"";";s:27:"additional_fields_languages";s:0:"";}', TRUE);