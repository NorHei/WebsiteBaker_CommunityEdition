<?php
$plugin_directory   = '567756a74c433621b';
$plugin_name        = 'WBLINK Filter';
$plugin_version     = '';
$plugin_status      = '';
$plugin_platform    = '';
$plugin_author      = '';
$plugin_license     = '';
$plugin_description = '';