<?php
$plugin_directory   = '348056a74ca00262e';
$plugin_name        = 'Relative URL';
$plugin_version     = '';
$plugin_status      = '';
$plugin_platform    = '';
$plugin_author      = '';
$plugin_license     = '';
$plugin_description = '';